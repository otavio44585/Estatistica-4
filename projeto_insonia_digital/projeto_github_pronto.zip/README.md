# Modelo Preditivo: Insônia Digital 🌙

Este repositório contém um modelo estatístico em Python para prever a latência do sono (tempo necessário para adormecer) com base no tempo de exposição a telas antes de dormir. O objetivo é demonstrar a relação matemática entre a insônia digital e o uso de dispositivos móveis.

## 📂 Estrutura do Repositório

- **`/dataset`**: Contém a base de dados (`dados_insonia.csv`) com registos de minutos de tela e minutos para adormecer.
- **`/codigo`**: Contém o script de treino do modelo de Regressão Linear (`treinar_modelo.py`).
- **`/relatorio`**: Relatórios e análises estatísticas geradas a partir do modelo.

## 🔬 Expansão do Projeto (Monitorização Física)

Inspirado nos conceitos de monitorização física noturna, o nosso modelo preditivo pode ser evoluído no futuro para integrar dados fisiológicos reais, tais como:
- **Oxigenação sanguínea e ritmo cardíaco** (medidos via oxímetro de pulso).
- **Agitação noturna e movimentação** (medidos via acelerómetro).
- **Fatores ambientais** do quarto (temperatura, humidade, ruído e luminosidade).

A inclusão destas variáveis transformará o algoritmo numa **Regressão Múltipla**, permitindo isolar com maior precisão o impacto da insônia digital face a perturbações físicas e ambientais.

## 🚀 Como Executar

1. Certifique-se de que tem o Python instalado, juntamente com as seguintes bibliotecas:
   ```bash
   pip install pandas scikit-learn matplotlib
   ```
2. Navegue até à pasta de código e execute o modelo:
   ```bash
   cd codigo
   python treinar_modelo.py
   ```
